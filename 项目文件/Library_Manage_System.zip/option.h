//
// Created by 谷岩 on 2022/12/23.
//

#ifndef LIBRARY_MANAGE_SYSTEM_OPTION_H
#define LIBRARY_MANAGE_SYSTEM_OPTION_H
void run();              //主菜单的选择函数 run就是运行的意思
void catagory_options(); //分类菜单的选择函数
#endif //LIBRARY_MANAGE_SYSTEM_OPTION_H
