//
// Created by 谷岩 on 2022/12/21.
//

#ifndef LIBRARY_MANAGE_SYSTEM_MENU_H
#define LIBRARY_MANAGE_SYSTEM_MENU_H
int main_menu();          //主菜单
int catagory_menu();      //分类管理菜单
void add_book_menu();     //入库菜单
void delete_book_menu();  //出库菜单

#endif //LIBRARY_MANAGE_SYSTEM_MENU_H
