//
// Created by ���� on 2022/12/28.
//

#ifndef LIBRARY_MANAGE_SYSTEM_DATA_IO_H
#define LIBRARY_MANAGE_SYSTEM_DATA_IO_H
void data_import();
void catagory_import(char *buf);
void book_import(char *buf);
void data_export();
void catagory_export();
void book_export();
#endif //LIBRARY_MANAGE_SYSTEM_DATA_IO_H
